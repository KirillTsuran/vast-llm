from pydantic import BaseModel, Field
from typing import Dict, Literal, Optional
from uuid import uuid4


def _no_parameters() -> Dict[str, object]:
    # A tool without parameters is a function with an empty argument list. An
    # empty object schema keeps templates that walk parameters.properties working
    return {"type": "object", "properties": {}}


class Function(BaseModel):
    """
    Represents a description of a tool function. As in the OpenAI API, only the
    name is required: description defaults to empty and omitting parameters
    declares a function that takes no arguments (#485).
    """

    name: str
    description: str = ""
    parameters: Dict[str, object] = Field(default_factory=_no_parameters)


class ToolSpec(BaseModel):
    """Wrapper for an inner tool function."""

    function: Function
    type: Literal["function"]


class Tool(BaseModel):
    """Represents an OAI tool description."""

    name: str

    # Makes more sense to be a dict, but OAI knows best
    arguments: str


class ToolCall(BaseModel):
    """Represents an OAI tool call.

    The ``index`` field is optional so it can be omitted in non-streaming
    responses (where OpenAI does not include it) via ``exclude_none=True``,
    while being set explicitly for streaming deltas where it is required
    by strict validators like the Vercel AI SDK.

    TOOL_CALL_SCHEMA:
     {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "array",
        "items": {
            "type": "object",
            "properties": {
                "function": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "arguments": {
                            # Converted to OAI's string in post process
                            "type": "object"
                        },
                    },
                    "required": ["name", "arguments"],
                },
            },
            "required": ["function"],
        },
    }
    """

    id: str = Field(default_factory=lambda: f"call_{uuid4().hex[:24]}")
    function: Tool
    type: Literal["function"] = "function"
    index: Optional[int] = None


class NamedToolFunction(BaseModel):
    """Represents a named function reference for tool_choice."""

    name: str


class NamedToolChoice(BaseModel):
    """Represents a named tool choice (forces a specific function call)."""

    function: NamedToolFunction
    type: Literal["function"] = "function"
