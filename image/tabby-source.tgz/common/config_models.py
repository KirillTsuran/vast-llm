from pydantic import (
    BaseModel,
    ConfigDict,
    constr,
    Field,
    PrivateAttr,
    field_validator,
)
from typing import List, Literal, Optional, Union


CACHE_SIZES = Literal["FP16", "Q8", "Q6", "Q4"]
CACHE_TYPE = Union[CACHE_SIZES, constr(pattern=r"^[2-8]\s*,\s*[2-8]$")]


class Metadata(BaseModel):
    """metadata model for config options"""

    include_in_config: Optional[bool] = Field(True)


class BaseConfigModel(BaseModel):
    """Base model for config models with added metadata"""

    _metadata: Metadata = PrivateAttr(Metadata())


class ConfigOverrideConfig(BaseConfigModel):
    """Model for overriding a provided config file."""

    # TODO: convert this to a pathlib.path?
    config: Optional[str] = Field(None, description="Path to an overriding config.yml file")

    _metadata: Metadata = PrivateAttr(Metadata(include_in_config=False))


class NetworkConfig(BaseConfigModel):
    """Options for networking"""

    host: Optional[str] = Field(
        "127.0.0.1",
        description=(
            "The IP to host on (default: 127.0.0.1).\n"
            "Use 0.0.0.0 to expose on all network adapters."
        ),
    )
    port: Optional[int] = Field(5000, description="The port to host on (default: 5000).")
    disable_auth: Optional[bool] = Field(
        False,
        description=(
            "Disable HTTP token authentication with requests.\n"
            "WARNING: This will make your instance vulnerable!\n"
            "Only turn this on if nothing but trusted local clients can reach the API.\n"
            "Note that web pages open in a browser on this machine also count as local\n"
            "callers; restrict allowed_origins below if you disable auth."
        ),
    )
    allowed_origins: Optional[List[str]] = Field(
        ["*"],
        description=(
            'Origins allowed to call the API from a browser (default: ["*"]).\n'
            "This is a CORS allowlist, not an auth mechanism: it only governs which\n"
            "web pages a browser will let read this API's responses.\n"
            'The default "*" means any site open in your browser can send requests to\n'
            "this instance, which matters most when disable_auth is on. Restrict this to\n"
            'your own frontends (e.g. ["http://localhost:8000"]) to close that off, or\n'
            "use an empty list [] to block all browser (cross-origin) callers."
        ),
    )
    disable_fetch_requests: Optional[bool] = Field(
        False,
        description=(
            "Disable fetching external content in response to requests,such as images from URLs."
        ),
    )
    send_tracebacks: Optional[bool] = Field(
        False,
        description=(
            "Send tracebacks over the API (default: False).\n"
            "NOTE: Only enable this for debug purposes."
        ),
    )
    api_servers: Optional[List[Literal["oai", "kobold"]]] = Field(
        ["OAI"],
        description=(
            'Select API servers to enable (default: ["OAI"]).\nPossible values: OAI, Kobold.'
        ),
    )
    sse_ping_interval: Optional[int] = Field(
        15,
        description=(
            "Seconds between SSE keep-alive pings on streaming responses (default: 15).\n"
            "Pings are SSE comments, ignored by compliant clients, and prevent\n"
            "connections from dropping during long prefills. Set to 0 to disable."
        ),
        ge=0,
    )
    access_log: Optional[bool] = Field(
        False,
        description=(
            "Log every HTTP request with client address, method, path and status "
            "(default: False).\n"
            "Generation requests are already logged in detail; this adds the rest, "
            "such as model list and health polls."
        ),
    )

    # Converts all strings in the api_servers list to lowercase
    # NOTE: Expand if more models need this validator
    @field_validator("api_servers", mode="before")
    def api_server_validator(cls, api_servers):
        return [server_name.lower() for server_name in api_servers]


# TODO: Migrate config.yml to have the log_ prefix
# This is a breaking change.
class LoggingConfig(BaseConfigModel):
    """Options for logging"""

    log_prompt: Optional[bool] = Field(
        False,
        description="Enable prompt logging (default: False).",
    )
    log_generation_params: Optional[bool] = Field(
        False,
        description="Enable generation parameter logging (default: False).",
    )
    log_requests: Optional[bool] = Field(
        False,
        description=(
            "Enable request logging (default: False).\nNOTE: Only use this for debugging!"
        ),
    )
    log_live_status: Optional[bool] = Field(
        True,
        description=(
            "Show a live status line below the log with cache usage and in-flight "
            "jobs (default: True).\n"
            "Only shown on an interactive terminal."
        ),
    )
    log_timestamps: Optional[bool] = Field(
        True,
        description=(
            "Prefix console log lines with the time of day (default: True).\n"
            "The log files under logs/ always carry full timestamps."
        ),
    )
    log_chat_completion_requests: Optional[bool] = Field(
        False,
        description=(
            "Write every /v1/chat/completions request to logs/debug/ as JSON (default: False).\n"
            "Also saves the fully templated prompt (the exact text sent to the tokenizer) "
            "as a .txt file with the same basename.\n"
            "PRIVACY WARNING: Enabling this creates a comprehensive request log, including the "
            "full message history and generation parameters. API keys are redacted, but prompts "
            "and user-provided content are preserved for bug-report reproduction."
        ),
    )


class ModelConfig(BaseConfigModel):
    """
    Options for model overrides and loading
    Please read the comments to understand how arguments are handled
    between initial and API loads
    """

    # TODO: convert this to a pathlib.path?
    model_dir: str = Field(
        "models",
        description=(
            "Directory to look for models (default: models).\n"
            "Windows users, do NOT put this path in quotes!"
        ),
    )
    inline_model_loading: Optional[bool] = Field(
        False,
        description=(
            "Allow direct loading of models "
            "from a completion or chat completion request (default: False).\n"
            "This method of loading is strict: a request naming a model that\n"
            "doesn't exist or fails to load is rejected instead of running on the\n"
            "loaded model. Enable dummy models to add exceptions for model names\n"
            "that clients send without meaning a specific model."
        ),
    )
    use_dummy_models: Optional[bool] = Field(
        False,
        description=(
            "Sends dummy model names when the models endpoint is queried. "
            "(default: False)\n"
            "Enable this if the client is looking for specific OAI models.\n"
        ),
    )
    dummy_model_names: List[str] = Field(
        default=["gpt-3.5-turbo"],
        description=(
            "A list of fake model names that are sent via the /v1/models endpoint. "
            '(default: ["gpt-3.5-turbo"])\n'
            "Also used as bypasses for strict mode if inline_model_loading is true."
        ),
    )
    model_name: Optional[str] = Field(
        None,
        description=(
            "An initial model to load.\n"
            "Make sure the model is located in the model directory!\n"
            "REQUIRED: This must be filled out to load a model on startup."
        ),
    )
    use_as_default: List[str] = Field(
        default_factory=list,
        description=(
            "Names of args to use as a fallback for API load requests (default: []).\n"
            "For example, if you always want cache_mode to be Q4 "
            'instead of on the inital model load, add "cache_mode" to this array.\n'
            "Example: ['max_seq_len', 'cache_mode']."
        ),
    )
    backend: Optional[str] = Field(
        None,
        description=(
            "Backend to use for this model (auto-detect if not specified)\nOptions: exllamav3"
        ),
    )
    max_seq_len: Optional[int] = Field(
        None,
        description=(
            "Max sequence length (default: 4096).\nSet to -1 to fetch from the model's config.json"
        ),
        ge=-1,
    )
    cache_size: Optional[int] = Field(
        None,
        description=(
            "Size of the prompt cache to allocate (default: max_seq_len).\n"
            "Must be a multiple of 256 and can't be less than max_seq_len."
        ),
        multiple_of=256,
        gt=0,
    )
    cache_mode: Optional[CACHE_TYPE] = Field(
        "FP16",
        description=(
            "Enable different cache modes for VRAM savings (default: FP16).\n"
            "Specify the pair k_bits,v_bits where k_bits and v_bits "
            "are integers from 2-8 (i.e. 8,8).\n"
            f"The legacy values {str(CACHE_SIZES)[15:-1]} are also accepted."
        ),
    )
    tensor_parallel: Optional[bool] = Field(
        False,
        description=(
            "Load model with tensor parallelism (default: False).\n"
            "Falls back to autosplit if GPU split isn't provided.\n"
            "This ignores the gpu_split_auto value."
        ),
    )
    tensor_parallel_backend: Optional[str] = Field(
        "native",
        description=(
            "Sets a backend type for tensor parallelism. (default: native).\n"
            "Options: native, nccl\n"
            "Native is recommended for PCIe GPUs\n"
            "NCCL is recommended for NVLink."
        ),
    )
    gpu_split_auto: Optional[bool] = Field(
        True,
        description=(
            "Automatically allocate resources to GPUs (default: True).\n"
            "Not parsed for single GPU users."
        ),
    )
    autosplit_reserve: List[float] = Field(
        [96],
        description=(
            "Reserve VRAM used when loading a model (default: 96 MB on GPU 0).\n"
            "Represented as an array of MB per GPU.\n"
            "A negative value excludes that GPU from the model split, so\n"
            "excluding every GPU will fail to load.\n"
            "Ignored for a model whose placement is already set by gpu_split\n"
            "or draft_gpu_split."
        ),
    )
    gpu_split: List[float] = Field(
        default_factory=list,
        description=(
            "Array of VRAM sizes to split between GPUs, in GB (default: []).\n"
            "Used both with and without tensor parallelism."
        ),
    )
    cpu_moe_offload_layers: Optional[int] = Field(
        0,
        description=(
            "Number of mixture-of-expert layers to offload to CPU inference (default: 0)\n"
            "Only affects MoE models. Set a large value such as 999 to offload all layers\n"
            "Mutually exclusive with cpu_moe_split_experts."
        ),
    )
    cpu_moe_split_experts: Optional[int] = Field(
        0,
        description=(
            "Number of routed experts per MoE layer to offload to CPU inference\n"
            "(default: 0). Unlike cpu_moe_offload_layers, this splits every MoE\n"
            "layer instead of offloading whole layers: the coldest experts are\n"
            "kept in system RAM and computed on the CPU, overlapping each\n"
            "layer's own GPU compute, with dynamic placement keeping hot\n"
            "experts in VRAM. Mutually exclusive with cpu_moe_offload_layers;\n"
            "not supported with tensor parallelism."
        ),
    )
    cpu_moe_threads: Optional[int] = Field(
        None,
        description=(
            "Worker thread count for CPU MoE inference (default: None).\n"
            "Applies to both cpu_moe_offload_layers and cpu_moe_split_experts.\n"
            "When unset, defers to the EXL3_MOE_CPU_THREADS environment\n"
            "variable, then half the CPU core count."
        ),
    )
    ngram_ram: Optional[bool] = Field(
        False,
        description=(
            "Load a model's n-gram embedding table fully into system RAM\n"
            "(default: False). Only affects PLE models with n-gram embeddings\n"
            "(e.g. Qwen3.8-Flash-Next). By default the table is streamed from\n"
            "disk during inference; loading it into RAM avoids per-token disk\n"
            "reads at the cost of tens of GB of system memory."
        ),
    )

    rope_scale: Optional[float] = Field(
        1.0,
        description=(
            "Rope scale (default: 1.0).\n"
            "Same as compress_pos_emb.\n"
            "Use if the model was trained on long context with rope.\n"
            "Leave blank to pull the value from the model."
        ),
    )
    rope_alpha: Optional[Union[float, Literal["auto"]]] = Field(
        None,
        description=(
            "Rope alpha (default: None).\n"
            'Same as alpha_value. Set to "auto" to auto-calculate.\n'
            "Leaving this value blank will either pull from the model "
            "or auto-calculate."
        ),
    )
    chunk_size: Optional[int] = Field(
        2048,
        description=(
            "Chunk size for prompt ingestion (default: 2048).\n"
            "A lower value reduces VRAM usage but decreases ingestion speed.\n"
            "NOTE: Effects vary depending on the model.\n"
            "An ideal value is between 512 and 4096."
        ),
        gt=0,
    )
    output_chunking: Optional[bool] = Field(
        True,
        description=(
            "Use output chunking (default: True)\n"
            "Instead of allocating cache space for the entire completion at once, "
            "allocate in chunks as needed.\n"
            "Used by EXL3 models only.\n"
        ),
    )
    max_batch_size: Optional[int] = Field(
        None,
        description=(
            "Set the maximum number of generation jobs that can run concurrently\n"
            "The default maximum batch size for transformer architectures is 32. Recurrent\n"
            "models with linear or sliding attention use more VRAM to support larger batches,\n"
            "so the default value is reduced to 4. If you do not require concurrency at all, you\n"
            "can reduce it further to minimize VRAM overhead."
        ),
        ge=1,
    )
    recurrent_checkpoint_interval: Optional[int] = Field(
        None,
        description=(
            "Tokens between recurrent state checkpoints near the end of the prompt and\n"
            "during generation (default: None, the engine's per-architecture default,\n"
            "2048 for most models). Only used by models with recurrent (linear or sliding\n"
            "attention) layers. Must be a multiple of 256."
        ),
        multiple_of=256,
        gt=0,
    )
    recurrent_checkpoint_interval_pp: Optional[int] = Field(
        None,
        description=(
            "Tokens between recurrent state checkpoints during prompt ingestion, further\n"
            "than 2 * chunk_size from the end of the prompt (default: None, the engine\n"
            "default of 32768). Only used by models with recurrent layers. Must be a\n"
            "multiple of 256 and is rounded up to a multiple of chunk_size.\n"
            "Recurrent states cannot be rolled back, so a request that edits an earlier\n"
            "part of a cached prompt replays from the last checkpoint before the edit.\n"
            "With the default, a long prompt is only checkpointed near its end and an\n"
            "early edit costs a full re-prefill; with a denser grid the replay cost becomes\n"
            "proportional to the distance from the edit to the end of the prompt.\n"
            "Each checkpoint costs one recurrent state of system RAM (148 MiB for a 27B\n"
            "hybrid with 48 recurrent layers), bounded by memory.sysmem_recurrent_cache,\n"
            "and cold prefill is 2-3% slower at 2048 or 1024."
        ),
        multiple_of=256,
        gt=0,
    )
    prompt_template: Optional[str] = Field(
        None,
        description=(
            "Set the prompt template for this model. (default: None)\n"
            "If empty, attempts to look for the model's chat template.\n"
            "If a model contains multiple templates in its tokenizer_config.json,\n"
            "set prompt_template to the name of the template you want to use.\n"
            "NOTE: Only works with chat completion message lists!"
        ),
    )
    vision: Optional[bool] = Field(
        False,
        description=("Enables vision support if the model supports it. (default: False)"),
    )
    sampling: Optional[dict] = Field(
        None,
        description=(
            "Sampler overrides for this model (default: None).\n"
            "Same syntax as the top-level sampling section: an optional\n"
            "override_preset naming a file in sampler_overrides, plus any sampler\n"
            "written inline as {override, force, additive}. Applied on top of the\n"
            "global sampling section while this model is loaded. Meant for the\n"
            "model folder's tabby_config.yml so each model can carry its own\n"
            "sampling defaults; request parameters still take precedence unless\n"
            "an override is forced."
        ),
    )
    template_vars_default: dict = Field(
        {},
        description=(
            "Default chat template variables (default: {}).\n"
            "Merged into the template variables of every chat completion request;\n"
            "values sent by the client take precedence. Use for model-specific\n"
            "reasoning knobs, e.g. {enable_thinking: true} or {reasoning_effort: high}."
        ),
    )
    template_vars_force: dict = Field(
        {},
        description=(
            "Forced chat template variables (default: {}).\n"
            "Like template_vars_default, but these override any values sent by the client."
        ),
    )
    force_enable_thinking: bool = Field(
        False,
        description=("DEPRECATED: Equivalent to template_vars_force: {enable_thinking: true}."),
    )
    reasoning: bool = Field(
        True,
        description=(
            "Enable the reasoning parser (default: True).\n"
            "Splits the response into reasoning_content and content fields. With the\n"
            "tokens below left at auto, reasoning is only parsed when the model's\n"
            "template or tokenizer shows which tags it uses."
        ),
    )
    reasoning_start_token: str = Field(
        "auto",
        description=(
            "Start token for the reasoning parser (default: auto).\n"
            "auto takes the tags from the detected tool format or the chat template;\n"
            "set both tokens explicitly to override."
        ),
    )
    reasoning_end_token: str = Field(
        "auto",
        description="End token for the reasoning parser (default: auto).",
    )
    start_in_reasoning: str = Field(
        "auto",
        description=(
            "Whether generation starts inside a reasoning block (default: auto).\n"
            "Options: auto, always, never\n"
            "auto guesses by scanning the end of the templated prompt for an\n"
            "unclosed reasoning start token."
        ),
    )
    tool_calls_in_reasoning: bool = Field(
        True,
        description=(
            "Parse tool calls that occur inside reasoning content (default: True).\n"
            "If False, tool call tags inside a reasoning block are treated as\n"
            "plain reasoning text."
        ),
    )
    reasoning_budget_tokens: Optional[int] = Field(
        None,
        description=(
            "Default reasoning token budget (default: None).\n"
            "When a request's reasoning content exceeds the budget, the server\n"
            "forces the end of the reasoning phase by injecting\n"
            "reasoning_budget_message followed by the model's end-of-reasoning\n"
            "tokens. 0 ends reasoning as soon as it starts; None or a negative\n"
            "value disables the budget. Overridable per request via\n"
            "reasoning_budget_tokens (aliases: reasoning_budget,\n"
            "thinking_budget, thinking_token_budget) or reasoning.max_tokens.\n"
            "Requires a reasoning format: reasoning tags, Harmony or Muse\n"
            "Glimmer."
        ),
    )
    reasoning_budget_message: Optional[str] = Field(
        None,
        description=(
            "Text injected before the end-of-reasoning tokens when the\n"
            "reasoning budget is exhausted (default: no text, only the end-of-reasoning\n"
            "tokens are forced). Overridable per request via reasoning_budget_message."
        ),
    )
    tool_format: Optional[str] = Field(
        "auto",
        description=(
            "Tool call format (default: auto). auto picks a parser from the model's\n"
            "chat template, tokenizer and architecture, and warns if none matches.\n"
            "Set a format name, e.g. 'qwen3_coder', to override; see the Tool Calling\n"
            "docs for the supported formats. Leave blank to disable tool call parsing."
        ),
    )
    harmony: Optional[bool] = Field(
        None,
        description=(
            "Parse responses in the Harmony message format (gpt-oss models).\n"
            "Auto-detected from the model's special tokens by default; set to\n"
            "true or false to override. Setting 'tool_format: harmony' is\n"
            "equivalent to setting this to true. When active, supersedes the\n"
            "reasoning and tool format settings."
        ),
    )
    muse_glimmer: Optional[bool] = Field(
        None,
        description=(
            "Parse responses in the Muse Glimmer message format.\n"
            "Auto-detected from the model's special tokens by default; set to\n"
            "true or false to override. Setting 'tool_format: muse_glimmer' is\n"
            "equivalent to setting this to true. When active, supersedes the\n"
            "reasoning and tool format settings."
        ),
    )

    _metadata: Metadata = PrivateAttr(Metadata())
    model_config = ConfigDict(protected_namespaces=())


class DraftModelConfig(BaseConfigModel):
    """
    Options for draft models (speculative decoding)
    This will use more VRAM!
    """

    draft_mode: Optional[Literal["model", "disabled", "mtp", "ngram"]] = Field(
        "model",
        description=(
            "Drafting mode (default: model).\n"
            "Options: model, disabled, mtp, ngram.\n"
            "In `model` mode, drafting is disabled if no draft_model_name is provided."
        ),
    )
    # TODO: convert this to a pathlib.path?
    draft_model_dir: Optional[str] = Field(
        "models",
        description="Directory to look for draft models (default: models)",
    )
    draft_model_name: Optional[str] = Field(
        None,
        description=(
            "An initial draft model to load.\nEnsure the model is in the model directory."
        ),
    )
    draft_rope_scale: Optional[float] = Field(
        1.0,
        description=(
            "Rope scale for draft models (default: 1.0).\n"
            "Same as compress_pos_emb.\n"
            "Use if the draft model was trained on long context with rope."
        ),
    )
    draft_rope_alpha: Optional[float] = Field(
        None,
        description=(
            "Rope alpha for draft models (default: None).\n"
            'Same as alpha_value. Set to "auto" to auto-calculate.\n'
            "Leaving this value blank will either pull from the model "
            "or auto-calculate."
        ),
    )
    draft_cache_mode: Optional[CACHE_TYPE] = Field(
        "FP16",
        description=(
            "Cache mode for draft models to save VRAM (default: FP16).\n"
            "Specify the pair k_bits,v_bits where k_bits and v_bits "
            "are integers from 2-8 (i.e. 8,8).\n"
            f"The legacy values {str(CACHE_SIZES)[15:-1]} are also accepted."
        ),
    )
    draft_gpu_split: List[float] = Field(
        default_factory=list,
        description=(
            "Array of VRAM sizes to split between GPUs, in GB (default: []).\n"
            "If this isn't filled in, the draft model is autosplit."
        ),
    )
    draft_num_tokens: Optional[int] = Field(
        None,
        description=(
            "Number of tokens to draft per iteration (default: draft model default)\n"
            "Recurrent (linear or sliding attention) models use more VRAM for longer drafts.\n"
            "This overhead multiplies with the max batch size, so for models with long drafts\n"
            "(e.g. DFlash with 15 tokens by default) shorter drafts may be preferable."
        ),
    )
    dynamic_draft: Optional[bool] = Field(
        False,
        description=(
            "Adjust number of draft tokens dynamically based on observed acceptance rates.\n"
            "Ceiling is given by num_draft_tokens."
        ),
    )
    ngram_match_min: Optional[int] = Field(
        2,
        description=(
            "Minimum match length for exllamav3 n-gram drafting (default: 2).\n"
            "Only used when draft_mode is ngram."
        ),
    )


class SamplingConfig(BaseConfigModel):
    """
    Options for Sampling. Besides override_preset, any sampler name may appear
    directly in this section as an inline override, e.g.

        temperature:
          override: 0.5
          force: false

    Inline overrides apply on top of the preset, or on their own without one.
    """

    model_config = ConfigDict(extra="allow")

    override_preset: Optional[str] = Field(
        None,
        description=(
            "Select a sampler override preset (default: None).\n"
            "Find this in the sampler-overrides folder.\n"
            "This overrides default fallbacks for sampler values "
            "that are passed to the API.\n"
            "NOTE: safe_defaults provides llama.cpp-style fallbacks (temperature 0.8, "
            "top_k 40, top_p 0.95, min_p 0.05)\n"
            "for frontends that don't send sampling parameters. Leaving this blank "
            "means no fallbacks at all.\n"
            "Individual overrides can also be written directly in this section\n"
            "(e.g. temperature: {override: 0.5, force: false}); they apply on top\n"
            "of the preset, or on their own if no preset is given."
        ),
    )

    def inline_overrides(self) -> dict:
        """Sampler overrides written directly in this section, keyed by sampler name."""

        return dict(self.model_extra or {})


class LoraInstanceModel(BaseConfigModel):
    """Model representing an instance of a Lora."""

    name: Optional[str] = None
    scaling: float = Field(1.0, ge=0)


class LoraConfig(BaseConfigModel):
    """Options for Loras"""

    # TODO: convert this to a pathlib.path?
    lora_dir: Optional[str] = Field(
        "loras", description="Directory to look for LoRAs (default: loras)."
    )
    loras: Optional[List[LoraInstanceModel]] = Field(
        None,
        description=(
            "List of LoRAs to load and associated scaling factors "
            "(default scale: 1.0).\n"
            "For the YAML file, add each entry as a YAML list:\n"
            "- name: lora1\n"
            "  scaling: 1.0"
        ),
    )


class EmbeddingsConfig(BaseConfigModel):
    """
    Options for embedding models and loading.
    NOTE: Embeddings requires the "extras" feature to be installed
    Install it via "pip install .[extras]"
    """

    # TODO: convert this to a pathlib.path?
    embedding_model_dir: Optional[str] = Field(
        "models",
        description=("Directory to look for embedding models (default: models)."),
    )
    embeddings_device: Optional[Literal["cpu", "auto", "cuda"]] = Field(
        "cpu",
        description=(
            "Device to load embedding models on (default: cpu).\n"
            "Possible values: cpu, auto, cuda.\n"
            "NOTE: It's recommended to load embedding models on the CPU.\n"
            "If using an AMD GPU, set this value to 'cuda'."
        ),
    )
    embedding_model_name: Optional[str] = Field(
        None,
        description="An initial embedding model to load on the infinity backend.",
    )


class MemoryConfig(BaseConfigModel):
    """Options for development and experimentation"""

    sysmem_recurrent_cache: Optional[int] = Field(
        4096,
        description=("Max size of recurrent cache in system memory, in MB (default: 4096)"),
    )
    sysmem_kv_cache: Optional[int] = Field(
        0,
        description=("Size of system memory second-tier K/V cache, in MB (default: 0)"),
    )
    sysmem_multimodal_cache: Optional[int] = Field(
        1024,
        description=(
            "Size of the image embedding cache in system memory, in MB (default: 1024).\n"
            "Encoded images are kept so repeated turns of a conversation don't re-run\n"
            "the vision model. Images already in use by a request are never evicted;\n"
            "a context whose images exceed the budget is cached only partially, with\n"
            "a warning. Only applies when vision is enabled."
        ),
        ge=0,
    )
    cuda_malloc_async: Optional[bool] = Field(
        False,
        description=(
            "Use the cudaMallocAsync allocator backend in Torch (default: False).\n"
            "When False, the allocator is left to the environment: unless\n"
            "PYTORCH_CUDA_ALLOC_CONF is set, ExLlamaV3 enables expandable segments in\n"
            "Torch's native allocator, which performs better than cudaMallocAsync.\n"
            "Enable this to force the cudaMallocAsync backend instead."
        ),
    )


class DeveloperConfig(BaseConfigModel):
    """Options for development and experimentation"""

    unsafe_launch: Optional[bool] = Field(
        False,
        description=(
            "Skip ExLlamav3 version check (default: False).\n"
            "WARNING: It's highly recommended to update your dependencies rather "
            "than enabling this flag."
        ),
    )
    disable_request_streaming: Optional[bool] = Field(
        False, description="Disable API request streaming (default: False)."
    )
    realtime_process_priority: Optional[bool] = Field(
        False,
        description=(
            "Set process to use a higher priority.\n"
            "For realtime process priority, run as administrator or sudo.\n"
            "Otherwise, the priority will be set to high."
        ),
    )
    seqlog: Optional[bool] = Field(
        False,
        description=("Enable extremely verbose seqlog logging, requires a running Seq server"),
    )
    seqlog_server_url: Optional[str] = Field(
        "http://localhost:5341",
        description=("Seq server url:port"),
    )
    seqlog_api_key: Optional[str] = Field(
        None,
        description=("Seq server API key (default: None)"),
    )


class TabbyConfigModel(BaseModel):
    """Base model for a TabbyConfig."""

    config: Optional[ConfigOverrideConfig] = Field(
        default_factory=ConfigOverrideConfig.model_construct,
    )
    network: Optional[NetworkConfig] = Field(
        default_factory=NetworkConfig.model_construct,
    )
    logging: Optional[LoggingConfig] = Field(
        default_factory=LoggingConfig.model_construct,
    )
    model: Optional[ModelConfig] = Field(
        default_factory=ModelConfig.model_construct,
    )
    draft_model: Optional[DraftModelConfig] = Field(
        default_factory=DraftModelConfig.model_construct,
    )
    lora: Optional[LoraConfig] = Field(
        default_factory=LoraConfig.model_construct,
    )
    embeddings: Optional[EmbeddingsConfig] = Field(
        default_factory=EmbeddingsConfig.model_construct,
    )
    sampling: Optional[SamplingConfig] = Field(
        default_factory=SamplingConfig.model_construct,
    )
    memory: Optional[MemoryConfig] = Field(
        default_factory=MemoryConfig.model_construct,
    )
    developer: Optional[DeveloperConfig] = Field(
        default_factory=DeveloperConfig.model_construct,
    )

    model_config = ConfigDict(validate_assignment=True, protected_namespaces=())
