"""Small replication of AutoTokenizer's chat template system for efficiency"""

import traceback
import aiofiles
import json
import pathlib
from datetime import datetime
from importlib.metadata import version as package_version
from typing import Optional
from jinja2 import Template, TemplateError, nodes
from jinja2.ext import Extension, loopcontrols
from jinja2.sandbox import ImmutableSandboxedEnvironment
from common.logger import xlogger
from packaging import version


from common.utils import unwrap


class TemplateLoadError(Exception):
    """Raised on prompt template load"""

    pass


VALID_TOOL_CALL_FORMATS = {"json", "xml", "auto"}


def _strftime_now(format):
    """Some models require strftime_now, e.g. Granite3."""

    current_time = datetime.now()
    return current_time.strftime(format)


def _raise_exception(message):
    """Exception handler for chat templates."""

    raise TemplateError(message)


def _tojson_compat(value, ensure_ascii=False, indent=None, separators=None, sort_keys=False):
    """JSON filter for chat templates, matching the transformers environment.

    Jinja's built-in ``tojson`` only takes ``indent``, HTML-escapes ``<``, ``>``,
    ``&`` and ``'`` into unicode escapes, sorts keys and returns ``Markup``, so
    templates calling ``tojson(ensure_ascii=False)`` fail on it and the ones that
    don't render text the model never saw in training. This filter has the same
    signature and defaults as the one transformers installs, so a template renders
    the same bytes here as under transformers or vLLM: raw UTF-8 (escaping
    non-ASCII text such as Chinese tool descriptions into ``\\uXXXX`` inflates
    token counts several-fold), ``json.dumps`` default separators, insertion key
    order, and a plain string return (autoescape is off, and a ``Markup`` value
    would HTML-escape any plain string a template concatenates with it).
    """
    return json.dumps(
        value,
        ensure_ascii=ensure_ascii,
        indent=indent,
        separators=separators,
        sort_keys=sort_keys,
    )


class _GenerationTagExtension(Extension):
    """Render-transparent {% generation %}...{% endgeneration %} blocks.

    Transformers uses these tags to mark assistant tokens for training-time
    masking; at inference the block contents render as-is.
    """

    tags = {"generation"}

    def parse(self, parser):
        lineno = next(parser.stream).lineno
        body = parser.parse_statements(("name:endgeneration",), drop_needle=True)
        return nodes.Scope(body).set_lineno(lineno)


def _create_environment() -> ImmutableSandboxedEnvironment:
    """Build the Jinja environment shared by all prompt templates."""

    environment = ImmutableSandboxedEnvironment(
        trim_blocks=True,
        lstrip_blocks=True,
        enable_async=True,
        extensions=[loopcontrols, _GenerationTagExtension],
    )
    environment.globals["strftime_now"] = _strftime_now
    environment.globals["raise_exception"] = _raise_exception
    environment.filters["tojson"] = _tojson_compat

    return environment


class PromptTemplate:
    """A template for chat completion prompts."""

    name: str
    raw_template: str
    template: Template

    # One environment shared by every template. Don't register anything
    # template-specific on it.
    environment: ImmutableSandboxedEnvironment = _create_environment()

    async def render(self, template_vars: dict):
        """Get a prompt from a template and a list of messages."""
        if version.parse(package_version("jinja2")) < version.parse("3.0.0"):
            raise ImportError(
                "Parsing these chat completion messages requires jinja2 3.0.0 "
                f"or greater. Current version: {package_version('jinja2')}\n"
                "Please update jinja by running the following command: "
                "pip install --upgrade jinja2"
            )

        rendered_template = await self.template.render_async(**template_vars)

        return rendered_template

    def compile(self, template_str: str):
        """Compiles and stores a jinja2 template"""

        return self.environment.from_string(template_str)

    def __init__(self, name: str, raw_template: str):
        """Initializer for the PromptTemplate class."""

        self.name = name
        self.raw_template = raw_template
        self.template = self.compile(raw_template)

    @classmethod
    async def from_file(cls, template_path: pathlib.Path):
        """Get a template from a jinja file."""

        # Add the jinja extension if it isn't provided
        if template_path.suffix.endswith(".jinja"):
            template_name = template_path.name.split(".jinja")[0]
        else:
            template_name = template_path.name
            template_path = template_path.with_suffix(".jinja")

        if template_path.exists():
            async with aiofiles.open(template_path, "r", encoding="utf8") as raw_template_stream:
                contents = await raw_template_stream.read()
                return cls(
                    name=template_name,
                    raw_template=contents,
                )
        else:
            # Let the user know if the template file isn't found
            raise TemplateLoadError(f'Chat template "{template_name}" not found in files.')

    @classmethod
    async def from_model_json(cls, json_path: pathlib.Path, key: str, name: Optional[str] = None):
        """Get a template from a JSON file. Requires a key and template name"""
        if not json_path.exists():
            raise TemplateLoadError(f'Model JSON path "{json_path}" not found.')

        async with aiofiles.open(json_path, "r", encoding="utf8") as config_file:
            contents = await config_file.read()
            model_config = json.loads(contents)
            chat_template = model_config.get(key)

            if not chat_template:
                raise TemplateLoadError(
                    "Could not find a value from chat_template key in the passed JSON. "
                    "Check the tokenizer config?"
                )

            if isinstance(chat_template, list):
                # Handles the new list style of chat templates
                if name:
                    wrapped_template = next(
                        (x for x in chat_template if x.get("name") == name),
                        {},
                    )
                else:
                    wrapped_template = chat_template[0]
                    name = unwrap(wrapped_template.get("name"), "from_tokenizer_config")

                selected_template = wrapped_template.get("template")

                if selected_template:
                    return PromptTemplate(name=name, raw_template=selected_template)
                else:
                    raise TemplateLoadError(
                        f'Chat template with name "{name}" not found in model templates list.'
                    )
            else:
                # Can safely assume the chat template is the old style
                return cls(
                    name="from_tokenizer_config",
                    raw_template=chat_template,
                )


def get_all_templates():
    """Fetches all templates from the templates directory"""

    template_directory = pathlib.Path("templates")
    return template_directory.glob("*.jinja")


def find_template_from_model(model_path: pathlib.Path):
    """Find a matching template name from a model path."""
    model_name = model_path.name
    template_files = get_all_templates()

    for filepath in template_files:
        template_name = filepath.stem.lower()

        # Check if the template name is present in the model name
        if template_name in model_name.lower():
            return template_name
        else:
            raise TemplateLoadError("Could not find template from model name.")


async def find_prompt_template(template_name, model_dir: pathlib.Path):
    """Tries to find a prompt template using various methods."""

    find_template_functions = [
        lambda: PromptTemplate.from_file(model_dir / "chat_template.jinja"),
        lambda: PromptTemplate.from_model_json(
            model_dir / "chat_template.json",
            key="chat_template",
        ),
        lambda: PromptTemplate.from_model_json(
            model_dir / "tokenizer_config.json",
            key="chat_template",
        ),
        lambda: PromptTemplate.from_file(find_template_from_model(model_dir)),
    ]

    # Find the template in the model directory if it exists
    model_dir_template_path = model_dir / "tabby_template.jinja"
    if model_dir_template_path.exists():
        find_template_functions[:0] = [lambda: PromptTemplate.from_file(model_dir_template_path)]

    # Add lookup from prompt template name if provided
    # TODO: Possibly link to the TokenizerConfig class
    if template_name:
        find_template_functions[:0] = [
            lambda: PromptTemplate.from_file(pathlib.Path("templates") / template_name),
            lambda: PromptTemplate.from_model_json(
                model_dir / "tokenizer_config.json",
                key="chat_template",
                name=template_name,
            ),
        ]

    # Continue on exception since functions are tried as they fail
    for template_func in find_template_functions:
        try:
            prompt_template = await template_func()
            if prompt_template is not None:
                return prompt_template
        except TemplateLoadError as e:
            xlogger.warning("TemplateLoadError", {"exception": str(e)}, details=f"{str(e)}")
            continue
        except Exception:
            xlogger.error(traceback.format_exc())
            xlogger.warning(
                "An unexpected error happened when trying to load the template. "
                "Trying other methods."
            )
            continue

    return None
